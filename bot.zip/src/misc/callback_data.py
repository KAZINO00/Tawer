from aiogram.utils.callback_data import CallbackData

movies_callback = CallbackData('hentai', 'action', 'code')

favorite_nav_callback = CallbackData('favorite_navigation', 'direction', 'current_page_number')
