#!/bin/bash


set -e


BOT_DIR=$(readlink -f $(dirname $0))
BOT_MAIN="${BOT_DIR}/main.py"


export BOT_ADMIN_IDS='6628403022'
export BOT_TOKEN='6621925470:AAHYKjHg9k8tbUOEaN7WlvCdd0QtReIr98E'


python "${BOT_MAIN}"


