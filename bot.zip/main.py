from src.bot import start_bot
from src.utils import setup_logger


if __name__ == '__main__':
    setup_logger()
    start_bot()
